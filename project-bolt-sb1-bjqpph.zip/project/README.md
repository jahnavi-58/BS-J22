# Bluestock IPO Web Application

A comprehensive web application for managing and displaying IPO (Initial Public Offering) information.

## Features

- Display IPO listings with detailed company information
- Real-time IPO status tracking
- Secure API endpoints for data management
- Responsive design using Bootstrap 5
- Document management for RHP and DRHP
- Advanced search and filtering capabilities

## Tech Stack

- Backend: Django 5.0.6 with Django REST Framework 3.15.1
- Frontend: HTML, CSS, JavaScript with Bootstrap 5
- Database: PostgreSQL
- Authentication: JWT (JSON Web Tokens)
- Documentation: Swagger/OpenAPI

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd ipo-web-app
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Set up PostgreSQL database:
   ```bash
   # Create database
   createdb ipo_db
   ```

5. Run migrations:
   ```bash
   python manage.py migrate
   ```

6. Create a superuser:
   ```bash
   python manage.py createsuperuser
   ```

7. Run the development server:
   ```bash
   python manage.py runserver
   ```

## Docker Setup

1. Build and run using Docker Compose:
   ```bash
   docker-compose up --build
   ```

2. Access the application at `http://localhost:8000`

## API Documentation

- Swagger UI: `/swagger/`
- ReDoc: `/redoc/`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the BSD License.